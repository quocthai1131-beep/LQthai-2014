# BÁO CÁO ĐỒ ÁN CUỐI KỲ
## HỌC PHẦN: LẬP TRÌNH MẠNG MÁY TÍNH
### ĐỀ TÀI: "ỨNG DỤNG ĐỒNG BỘ TỆP TIN (CLIENT-SERVER FILE SYNCHRONIZATION)"

**TRƯỜNG ĐẠI HỌC CÔNG NGHỆ TP.HCM (HUTECH)**  
**KHOA CÔNG NGHỆ THÔNG TIN**  
**LỚP:** 23DTHB1 &bull; **MÃ NHÓM:** 14  

---

### 👨‍💻 THÀNH VIÊN NHÓM VÀ PHÂN CÔNG NHIỆM VỤ
| STT | Họ và Tên | MSSV | Vai trò | Nhiệm vụ chính được giao |
|:---:|:---|:---:|:---:|:---|
| 1 | **Trần Quốc Nguyễn** | **2380601506** | **Trưởng nhóm** | Thiết kế Socket TCP đa luồng, tích hợp bảo mật SSL/TLS (Keystore/Truststore PKCS12), điều phối kiến trúc & File Locking. |
| 2 | **Bùi Nhật Quỳnh Hương** | **2380600941** | Thành viên | Xây dựng giao thức trao đổi Metadata, thuật toán quét thư mục NIO.2, thuật toán kiểm tra mã băm SHA-256 và phát hiện xung đột. |
| 3 | **Lý Quốc Thái** | **2380602014** | Thành viên | Xây dựng động cơ chia khối (Chunking Engine 64KB-256KB), cơ chế xác nhận từng khối (ACK/NACK), và cơ chế tiếp tục truyền tải (Resume Transfer). |
| 4 | **Nguyễn Trung Trực** | **2380602385** | Thành viên | Thiết kế giao diện đồ họa NetBeans Swing JFrame Forms (`.form` Matisse), tiến trình truyền tải (JProgressBar), Log thời gian thực, lập lịch đồng bộ tự động. |

---

## 1. GIỚI THIỆU & MỤC TIÊU ĐỀ TÀI
Trong môi trường làm việc phân tán, việc giữ cho dữ liệu giữa máy trạm (Client) và máy chủ (Server) luôn đồng nhất, bảo mật và toàn vẹn là một bài toán mạng cốt lõi. 

Đề tài **Ứng dụng Đồng bộ Tệp tin (Client-Server File Synchronization)** giải quyết trọn vẹn bài toán:
- Tự định nghĩa giao thức tầng ứng dụng tối ưu chạy trên nền Socket TCP.
- Mã hóa toàn bộ dữ liệu điều khiển và truyền tải tệp tin bằng giao thức bảo mật tiên tiến **SSL/TLS (TLSv1.3 / TLSv1.2)**.
- Phục vụ truyền tải các tệp tin dung lượng lớn trong mạng thời gian thực nhờ kỹ thuật **Chia nhỏ khối dữ liệu (Chunking)** kết hợp **Xác nhận từng khối (ACK Engine)**.
- Đảm bảo tính toàn vẹn 100% bằng thuật toán mã băm **SHA-256**.
- Giải quyết triệt để các lỗ hổng mạng: **Quy tắc giải quyết xung đột (Conflict Resolution)**, **Tiếp tục truyền tải khi đứt mạng (Resume Transfer)**, **Chống tấn công Path Traversal**, và **Khóa đồng thời tệp tin (File Locking)**.

---

## 2. KIẾN TRÚC HỆ THỐNG VÀ GIAO THỨC TẦNG ỨNG DỤNG

### 2.1. Cấu trúc Metadata của tệp tin
Mỗi tệp tin trong thư mục đồng bộ được mô tả qua cấu trúc `FileMetadata`:
- `relativePath`: Đường dẫn tương đối chuẩn hóa (ví dụ: `documents/baocao.docx`).
- `fileName`: Tên tệp tin (`baocao.docx`).
- `fileSize`: Kích thước tệp (bytes).
- `lastModified`: Mốc thời gian chỉnh sửa cuối (epoch millis).
- `sha256`: Mã băm SHA-256 kiểm tra toàn vẹn nội dung.
- `isDeleted`: Cờ đánh dấu tệp đã bị xóa (Tombstone).

### 2.2. Tập lệnh giao thức (Application Protocol Commands)
1. `HELLO` / `HELLO_OK`: Bắt tay thiết lập phiên kết nối và kiểm tra tính tương thích phiên bản giao thức giữa Client và Server.
2. `SEND_METADATA` / `META` / `META_END`: Client gửi danh mục cây tệp tin hiện tại lên Server.
3. `PLAN_ITEM` / `PLAN_END`: Server đối chiếu metadata hai phía, sinh ra kế hoạch đồng bộ (`SyncPlan`) gửi ngược về cho Client.
4. `UPLOAD_START` / `UPLOAD_RESUME`: Client thông báo bắt đầu tải lên; Server kiểm tra file tạm `.part` để trả về vị trí chunk tiếp tục (Resume).
5. `UPLOAD_CHUNK` / `UPLOAD_ACK`: Client gửi từng khối (64KB/128KB/256KB) kèm SHA-256 của khối; Server kiểm tra và phản hồi ACK.
6. `UPLOAD_END` / `UPLOAD_SUCCESS`: Client báo hoàn tất; Server ghép file và xác thực SHA-256 tổng thể.
7. `DOWNLOAD_START` / `DOWNLOAD_RESUME` / `DOWNLOAD_CHUNK` / `DOWNLOAD_ACK` / `DOWNLOAD_END`: Tương tự cho chiều tải về từ Server.
8. `DELETE_FILE` / `DELETE_SUCCESS`: Đồng bộ hóa trạng thái xóa tệp tin.
9. `BYE`: Đóng phiên làm việc Socket an toàn.

---

## 3. CÁC TÍNH NĂNG VÀ THUẬT TOÁN ĐẶC BIỆT (THEO YÊU CẦU GIẢNG VIÊN)

### 3.1. Quy tắc xử lý xung đột tệp (Conflict Resolution)
- **Tình huống**: Tệp tin `data.txt` bị cả hai phía Client và Server chỉnh sửa độc lập trong lúc mất mạng (hai bên có timestamp mới và hash khác nhau).
- **Quy tắc bảo toàn dữ liệu**: Hệ thống **tuyệt đối không tự ý ghi đè**.
- **Giải pháp**:
  - Sao lưu bản Client sang tên mới: `data_conflict_Client_[yyyyMMdd_HHmmss].txt`.
  - Tải bản mới từ Server về `data.txt`.
  - Giữ lại cả hai phiên bản để người dùng tự đối chiếu mà không bị mất dữ liệu.

### 3.2. Cơ chế Tiếp tục truyền tải (Resume Transfer)
- Khi truyền tệp tin lớn (hàng chục đến hàng trăm MB), dữ liệu được lưu tạm dưới dạng `[tên_tệp].part`.
- Nếu xảy ra sự cố đứt kết nối tại chunk thứ 50/100:
  - Khi kết nối lại, Server/Client đọc kích thước file `.part` hiện tại: `offset = partFile.length()`.
  - Số chunk đã có: `existingChunks = offset / chunkSize`.
  - Bên gửi chỉ cần truyền từ chunk thứ 51 trở đi, tiết kiệm băng thông và thời gian truyền tải.

### 3.3. Bảo mật SSL/TLS và Keystore PKCS12
- Sử dụng chứng chỉ bảo mật mã hóa **TLSv1.3**.
- Server sử dụng `server.keystore` (chứa RSA 2048-bit Private Key và Certificate tự ký).
- Client sử dụng `client.truststore` và `TrustManager` thông minh, giúp chạy thử nghiệm mượt mà trên môi trường mạng LAN/Internet mà không bị lỗi xác thực PKIX.

### 3.4. Phòng chống tấn công Path Traversal
- Lớp `PathSecurity.resolveAndValidate(rootDir, relativePath)` chuẩn hóa đường dẫn tương đối, loại bỏ các ký tự độc hại (`..`, `:`, `/`), và đối chiếu với đường dẫn chuẩn (Canonical Path) để đảm bảo không một tệp tin nào được đọc/ghi vượt ra khỏi thư mục đồng bộ.

### 3.5. Cơ chế khóa đa luồng (Concurrent File Locking)
- Lớp `FileLockManager` sử dụng `ConcurrentHashMap` chứa các `ReentrantReadWriteLock` theo đường dẫn tương đối.
- Khi một Client đang tải lên/sửa tệp, hệ thống giữ WriteLock; khi đang tải về, hệ thống giữ ReadLock. Ngăn chặn triệt để tình trạng xung đột ghi đè giữa nhiều luồng/Client cùng lúc.

---

## 4. GIAO DIỆN NGƯỜI DÙNG & WEB DASHBOARD
- **Giao diện NetBeans JFrame Form (`.form` + `.java`)**:
  - `MainLauncherForm`: Trung tâm điều khiển cho phép mở Server, mở Client, mở đồng thời cả hai hoặc mở Web Dashboard.
  - `ServerForm`: Cấu hình Port, bật/tắt SSL, chọn thư mục, quản lý tệp trên Server, xem danh sách Client nối mạng, theo dõi Log trực tiếp.
  - `ClientForm`: Kết nối Server, chọn thư mục Client, bấm Đồng bộ thủ công, bật Đồng bộ tự động theo chu kỳ (Scheduled), bảng Kế hoạch đồng bộ, thanh tiến trình file và tổng thể.
- **Web Monitoring Dashboard (Port 8088)**:
  - Máy chủ HTTP siêu nhẹ tích hợp sẵn phục vụ giao diện HTML5/Tailwind CSS hiện đại.
  - Cập nhật số liệu thống kê (Số file, dung lượng, clients online, trạng thái SSL).
  - Tự động làm mới dữ liệu và hiển thị live console logs.

---

## 5. KẾT QUẢ KIỂM THỬ HỆ THỐNG TOÀN DIỆN (QA TEST SUITE)
Hệ thống được kiểm tra nghiêm ngặt bằng bộ kiểm thử tự động tích hợp (`com.nhom14.filesync.test.TestRunner`). Kết quả đạt **8/8 Tests Passed (100% thành công)**:

| STT | Kịch bản kiểm thử (Test Case) | Yêu cầu nghiệp vụ / Rubric Giảng viên | Kết quả | Ghi chú kỹ thuật |
|:---:|:---|:---|:---:|:---|
| **1** | **Path Traversal Security** | Ngăn chặn truy cập file trái phép ngoài thư mục gốc | **PASS** | `PathSecurity` ném `SecurityException` ngay lập tức khi phát hiện `../../cmd.exe` |
| **2** | **SSL/TLS & Web Dashboard** | Khởi động TCP Socket SSL/TLS và HTTP Monitoring Server | **PASS** | Socket SSL PKCS12 sẵn sàng tại cổng 9095; Web Dashboard phản hồi HTTP `200 OK` tại `http://localhost:8088` |
| **3** | **Large File Chunking & SHA-256** | Chia nhỏ tệp tin (>180KB, chunk 64KB) và xác thực toàn vẹn | **PASS** | Chia 3 khối dữ liệu (64KB, 64KB, 51.6KB), truyền tải bảo mật, ghép file và kiểm tra khớp mã băm SHA-256 |
| **4** | **Resume Transfer (.part)** | Tiếp tục truyền tải từ khối dở dang khi bị gián đoạn kết nối | **PASS** | Nhận diện file `.part`, tính toán chính xác `resumeOffset` (65536 bytes) và tiếp tục gửi từ chunk 1/3 |
| **5** | **Conflict Resolution** | Quy tắc xử lý xung đột: Cả 2 bên đều sửa độc lập khi mất mạng | **PASS** | Hệ thống **tuyệt đối không ghi đè**; sao lưu bản Client thành `[name]_conflict_Client_[timestamp].[ext]`, tải bản Server về để đối chiếu |
| **6** | **Bidirectional Deletion Sync** | Đồng bộ trạng thái xóa tệp tin 2 chiều dựa trên Snapshot | **PASS** | Client xóa tệp `delete_me.txt` -> Đồng bộ -> Server tự động xóa tệp tương ứng an toàn |
| **7** | **Multi-Client Concurrency** | Khóa tệp tin đa luồng, chống tranh chấp tài nguyên (FileLockManager) | **PASS** | `ReentrantReadWriteLock` cho phép đọc đồng thời nhiều luồng và khóa ghi độc quyền |
| **8** | **Sliding Window / Batch ACK** | Tối ưu hóa tốc độ đường truyền độ trễ cao bằng Batch Transmission | **PASS** | Truyền tải hàng loạt chunk và xác nhận theo khối (Batch ACK), tối ưu hóa băng thông |

---

## 6. ĐÁNH GIÁ MỨC ĐỘ ĐÁP ỨNG TIÊU CHÍ GIẢNG VIÊN (CHECKLIST)
- [x] **TCP Socket đa luồng & SSL/TLS**: Triển khai `SSLSocket`, `SSLServerSocket`, `TLSv1.3`/`TLSv1.2` với Keystore PKCS12 tự sinh bằng `keytool`.
- [x] **Giao thức tầng ứng dụng tự định nghĩa**: Trao đổi Metadata (`fileName`, `relativePath`, `fileSize`, `lastModified`, `sha256`) và các mã lệnh `LIST`, `UPLOAD`, `DOWNLOAD`, `DELETE`.
- [x] **Chunking & ACK Checksum**: Phân mảnh cố định (64KB - 256KB), ACK từng khối hoặc theo nhóm, kiểm tra toàn vẹn SHA-256 từng chunk và toàn file.
- [x] **Quy tắc xử lý xung đột (Bắt buộc bổ sung)**: Phát hiện xung đột 2 đầu, đổi tên bản Client giữ nguyên dữ liệu, cập nhật bản Server để đối chiếu.
- [x] **Cơ chế tiếp tục truyền tải (Resume transfer)**: Sử dụng file tạm `.part`, đọc offset dở dang, truyền nối tiếp không gửi lại từ đầu.
- [x] **Cửa sổ trượt / Batch ACK**: Hỗ trợ 2 chế độ `STOP_AND_WAIT` và `BATCH_WINDOW`.
- [x] **Bảo mật Path Traversal**: Lớp bảo vệ `PathSecurity` kiểm tra `canonicalPath`.
- [x] **Khóa tệp tin (File Locking)**: `FileLockManager` chống xung đột đa người dùng đồng thời.
- [x] **Giao diện Apache NetBeans**: 100% chuẩn JFrame Forms visual (`.java` + `.form`), hỗ trợ NetBeans GUI Builder kéo thả trực quan.
- [x] **Web Monitoring Dashboard**: Giám sát thời gian thực qua giao diện Web nhẹ tại cổng 8088.
