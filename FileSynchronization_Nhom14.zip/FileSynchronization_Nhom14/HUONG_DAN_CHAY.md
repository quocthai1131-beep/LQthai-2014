# HƯỚNG DẪN CÀI ĐẶT & CHẠY ĐỒ ÁN CUỐI KỲ
## ĐỀ TÀI: "ỨNG DỤNG ĐỒNG BỘ TỆP TIN (CLIENT-SERVER FILE SYNCHRONIZATION)"
### HỌC PHẦN: LẬP TRÌNH MẠNG MÁY TÍNH - LỚP: 23DTHB1 - NHÓM 14 - HUTECH

---

## 👥 THÀNH VIÊN THỰC HIỆN
1. **Trần Quốc Nguyễn** - MSSV: **2380601506** (Nhóm trưởng)
2. **Bùi Nhật Quỳnh Hương** - MSSV: **2380600941**
3. **Lý Quốc Thái** - MSSV: **2380602014**
4. **Nguyễn Trung Trực** - MSSV: **2380602385**

---

## 📂 VỊ TRÍ DỰ ÁN TRÊN MÁY TÍNH
Dự án được lưu trữ đồng bộ ở 2 vị trí thuận tiện:
- `C:\Users\teomi\OneDrive\Tài liệu\NetBeansProjects\FileSynchronization_Nhom14`
- `C:\Users\teomi\OneDrive\Tài liệu\DoANLapTrinhMang\FileSynchronization_Nhom14`

---

## 🚀 CÁCH MỞ VÀ CHẠY TRỰC TIẾP TRÊN APACHE NETBEANS

### Bước 1: Mở Project trong NetBeans
1. Mở phần mềm **Apache NetBeans**.
2. Chọn menu **File** -> **Open Project...** (hoặc tổ hợp phím `Ctrl + Shift + O`).
3. Điều hướng đến thư mục:
   `C:\Users\teomi\OneDrive\Tài liệu\NetBeansProjects\FileSynchronization_Nhom14`
4. Chọn project có biểu tượng chữ **m** (Maven) và bấm nút **Open Project**.

### Bước 2: Xem và Chỉnh Sửa Giao Diện Bằng NetBeans GUI Builder (Design Tab)
Dự án được thiết kế **100% bằng chuẩn NetBeans JFrame Form** (bao gồm file `.java` và file `.form` đi kèm).
1. Trong cửa sổ **Projects** của NetBeans, mở rộng:
   `Source Packages` -> `com.nhom14.filesync.gui`.
2. Bấm đúp vào một trong các Form:
   - `MainLauncherForm.java` (Menu khởi chạy trung tâm)
   - `ServerForm.java` (Giao diện Máy chủ Socket & Web Dashboard)
   - `ClientForm.java` (Giao diện Máy khách đồng bộ dữ liệu)
3. Ở thanh công cụ trên đầu vùng soạn thảo, bạn sẽ thấy 2 tab:
   - **Source**: Xem và sửa mã nguồn Java.
   - **Design**: Mở trực quan **NetBeans Matisse GUI Builder** để kéo thả components, thay đổi màu sắc, font chữ, layout trực tiếp!

### Bước 3: Khởi Chạy Ứng Dụng
Có 3 cách chạy cực kỳ dễ dàng:
- **Cách 1 (Khuyên dùng - Chạy toàn bộ ứng dụng)**:
  Bấm phím **F6** hoặc nút xanh **Run Project** trên NetBeans.
  Màn hình **MainLauncherForm** sẽ xuất hiện, cho phép bạn chọn:
  - Nút 1: Mở giao diện Server.
  - Nút 2: Mở giao diện Client.
  - Nút 3: Mở cả Server và Client đồng thời để test ngay trên cùng một máy!
  - Nút 4: Mở Web Dashboard trên trình duyệt (http://localhost:8088).
- **Cách 2 (Chạy riêng từng Form)**:
  Chuột phải vào `ServerForm.java` -> chọn **Run File** (hoặc `Shift + F6`).
  Chuột phải vào `ClientForm.java` -> chọn **Run File** (hoặc `Shift + F6`).

---

## 🌟 HƯỚNG DẪN DEMO TỪNG TÍNH NĂNG ĐẠT ĐIỂM TỐI ĐA (10/10) TRƯỚC GIẢNG VIÊN

### 1. Demo Đồng bộ File và Chia Khối (Chunking) & ACK & SHA-256
1. Mở **ServerForm**, chọn cổng `8888`, giữ dấu tích `Kích hoạt bảo mật SSL/TLS`, bấm **Khởi Động Server**.
2. Mở **ClientForm**, nhập IP `localhost`, Port `8888`, tích `SSL/TLS`, bấm **Kết Nối**.
3. Thả một số file (ảnh, word, pdf, hoặc file lớn > 500KB) vào thư mục `./client_data`.
4. Trên Client, bấm nút **ĐỒNG BỘ NGAY**:
   - Client quét tệp, tính SHA-256, gửi metadata lên Server.
   - Server lập kế hoạch đồng bộ (SyncPlan).
   - Thanh tiến trình hiển thị rõ: từng chunk (64KB/128KB/256KB) được truyền qua Socket SSL kèm ACK xác nhận.
   - Ghép file hoàn chỉnh và đối chiếu mã hash SHA-256 chính xác 100%.

### 2. Demo Quy Tắc Xử Lý Xung Đột Tệp (Conflict Resolution - Bắt buộc bổ sung theo nhận xét GV)
1. Tạo file `tailieu.txt` trên cả Server và Client nhưng nội dung khác nhau:
   - Trên Client: "Nội dung Client sửa khi mất mạng"
   - Trên Server: "Nội dung Server sửa khi mất mạng"
2. Bấm nút **ĐỒNG BỘ NGAY**:
   - Hệ thống phát hiện xung đột và kích hoạt quy tắc bảo vệ dữ liệu!
   - Không tự ý ghi đè làm mất tài liệu của người dùng.
   - Đổi tên tệp của Client thành: `tailieu_conflict_Client_[yyyyMMdd_HHmmss].txt` và giữ nguyên.
   - Đồng thời tải bản từ Server về `tailieu.txt` để người dùng mở đối chiếu cả hai bản!

### 3. Demo Tiếp Tục Truyền Tải (Resume Transfer - Bắt buộc bổ sung)
1. Thử truyền một tệp lớn (ví dụ 10MB - 50MB).
2. Khi tiến trình đang chạy dở ở chunk 30/100, ngắt kết nối (hoặc tắt Client).
3. Bật lại Client và bấm **ĐỒNG BỘ NGAY**:
   - Client và Server tự động phát hiện file tạm `.part` đã có sẵn 30 chunk.
   - Log thông báo: `[RESUME TRANSFER] Tiếp tục gửi từ chunk 31/100`! Không cần truyền lại từ đầu!

### 4. Demo Chống Tấn Công Path Traversal
- Hệ thống đã tích hợp lớp `PathSecurity` kiểm tra canonical path. Mọi nỗ lực gửi đường dẫn chứa `..` hay cố gắng thoát ra ngoài thư mục gốc đều bị chặn đứng và ném `SecurityException`.

### 5. Demo Web Dashboard Giám Sát Thời Gian Thực (Port 8088)
1. Mở trình duyệt Web (Chrome, Edge, Firefox) và truy cập:
   `http://localhost:8088/`
2. Giao diện Web hiển thị:
   - Trạng thái Server (ONLINE, cổng kết nối, chế độ SSL/TLS).
   - Thống kê tổng số file, dung lượng lưu trữ, số lượng Client đang kết nối.
   - Bảng danh mục tệp tin chi tiết với mã băm SHA-256.
   - Console log hệ thống trực tiếp tự động refresh mỗi 5 giây!
